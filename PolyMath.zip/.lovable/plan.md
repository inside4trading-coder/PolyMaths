

# Rebranding Visual: PolyMath → Bloomberg Terminal Aesthetic

Refresh visual completo manteniendo nombre, logo y estructura. Migrar del cyan terminal actual a una estética **Bloomberg-inspired**: oscura, profesional, data-dense, con acentos **amber/orange**.

---

## Paleta de Color

```text
ACTUAL (Cyan Terminal)          →  NUEVO (Bloomberg Amber)
─────────────────────────────────────────────────────────
Primary: cyan (#00d4ff)         →  Amber (#F59E0B / warm orange)
Background: dark navy (#0a0f1a) →  Near-black (#0C0E12)
Card: dark navy lighter         →  Charcoal (#12151B)
Border: navy border             →  Subtle gray (#1E2028)
Muted text: cool gray           →  Warm gray (#8B8D97)
Success/Bull: green (keep)      →  Green (keep, slightly warmer)
Destructive/Bear: red (keep)    →  Red (keep)
Glow effects: cyan glow         →  Amber glow
```

## Tipografia

Mantener **JetBrains Mono** como fuente principal (terminal feel), pero agregar **Inter** como complementaria para textos largos (descriptions, landing copy). Actualmente Inter se importa pero no se usa.

```text
ACTUAL                          →  NUEVO
─────────────────────────────────────────
font-sans: JetBrains Mono      →  Inter (body text, landing)
font-mono: JetBrains Mono      →  JetBrains Mono (data, dashboard)
```

## Cambios por Archivo

### 1. `src/index.css` — Paleta de colores
- Cambiar `--primary` de cyan a amber (`38 92% 50%`)
- Oscurecer `--background` y `--card` ligeramente
- Warm-shift `--muted-foreground` y `--border`
- Actualizar `--glow-primary` a amber
- Actualizar `--accent-foreground` a amber
- Actualizar `--ring` a amber
- Sidebar variables: amber primary
- Light mode: amber primary con variaciones claras
- Chart colors: amber, orange, gold tones como primarios

### 2. `tailwind.config.ts` — Typography
- `font-sans`: cambiar a `['Inter', 'sans-serif']`
- `font-mono`: mantener `['JetBrains Mono', 'monospace']`
- Esto da Inter para copy general y JetBrains para datos/dashboard

### 3. Landing: `HeroSection.tsx`
- Actualizar badge text y copy para reflejar tono más profesional
- Cambiar "⚡" por algo más sobrio (ej: `▸`)
- Ajustar classes que hardcodean cyan references

### 4. Landing: `FeaturesSection.tsx`
- Reemplazar emojis por iconos Lucide para look más profesional
- Ajustar tag "Beta" color de destructive a amber variant

### 5. Landing: `LandingNav.tsx`, `FooterSection.tsx`
- Actualizar version badge styling
- Reemplazar emoji 🌐 por icono Lucide Globe

### 6. `Sidebar.tsx`
- Reemplazar emojis de navegación por iconos Lucide (📡→Radar, 💳→Wallet, 🧠→Brain, 🤖→Bot, 📈→TrendingUp, ⚙️→Settings)
- Esto es el cambio más impactante para el feel Bloomberg

### 7. `src/components/ui/badge.tsx`
- Actualizar colores default de cyan a amber

### 8. Auth page `src/pages/Auth.tsx`
- Ningún cambio estructural, hereda colores de CSS vars automáticamente

### 9. `index.html` — Meta tags
- Actualizar description/OG tags para reflejar tono más profesional

### 10. Componentes de dashboard (StatusStrip, Header, etc.)
- Heredan automáticamente via CSS variables, solo revisar hardcoded colors

---

## Impacto Visual Esperado

```text
ANTES                           DESPUÉS
─────────────────────────────────────────────
Cyan glows, gaming feel         Amber/orange, professional
Emojis en sidebar               Lucide icons, clean
Mono everywhere                 Inter for prose, Mono for data
Cool-toned grays                Warm-toned grays
"Hacker terminal"               "Bloomberg professional"
```

## Archivos a Modificar

| Archivo | Tipo de cambio |
|---------|---------------|
| `src/index.css` | Paleta completa (mayor impacto) |
| `tailwind.config.ts` | Typography font-sans → Inter |
| `src/components/layout/Sidebar.tsx` | Emojis → Lucide icons |
| `src/components/landing/HeroSection.tsx` | Copy + badge refinement |
| `src/components/landing/FeaturesSection.tsx` | Emojis → icons |
| `src/components/landing/LandingNav.tsx` | Emoji → icon |
| `src/components/landing/FooterSection.tsx` | Minor styling |
| `src/components/landing/HowItWorksSection.tsx` | Emojis → icons/numbers |
| `index.html` | Meta description tone |

No se requieren cambios de base de datos ni edge functions.

